from django.apps import AppConfig


class SuperAdminUserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'super_admin_user'
